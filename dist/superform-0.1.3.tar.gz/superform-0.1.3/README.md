# superform

`superform` is a CLI tool that scans structured text files from the current directory (or a provided path), validates them, and rewrites them with consistent formatting.

Supported formats:
- YAML: `.yaml`, `.yml`
- JSON: `.json`
- XML family: `.xml`, `.xsd`, `.xsl`, `.svg`, `.wsdl`, `.plist`, `.xhtml`, `.config`, `.csproj`, `.vbproj`, `.fsproj`, `.props`, `.targets`, `.resx`

## Install

```bash
cd superform
pip install -e .
```

## Usage

```bash
# scan from current directory and auto-fix files
superform

# scan another directory
superform /path/to/repo

# check only (no writes)
superform --check

# show each processed file
superform --verbose

# validate only a single file
superform path/to/file.json --check
```

## Exit codes

- `0`: all scanned files are valid (and fixed if not in check mode)
- `1`: at least one scanned file has a parse error
