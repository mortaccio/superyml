from pathlib import Path

from superform.core import iter_supported_files, iter_yaml_files, normalize_structured_file, normalize_yaml_file


def test_iter_yaml_files_filters_extensions(tmp_path: Path) -> None:
    (tmp_path / "a.yaml").write_text("a: 1\n", encoding="utf-8")
    (tmp_path / "b.yml").write_text("b: 2\n", encoding="utf-8")
    (tmp_path / "c.txt").write_text("x", encoding="utf-8")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "x.yaml").write_text("a: 1\n", encoding="utf-8")

    files = sorted(p.name for p in iter_yaml_files(tmp_path))
    assert files == ["a.yaml", "b.yml"]


def test_iter_supported_files_detects_multiple_formats(tmp_path: Path) -> None:
    (tmp_path / "a.yaml").write_text("a: 1\n", encoding="utf-8")
    (tmp_path / "b.json").write_text("{\"b\":2}", encoding="utf-8")
    (tmp_path / "c.xml").write_text("<c/>", encoding="utf-8")
    (tmp_path / "d.wsdl").write_text("<definitions/>", encoding="utf-8")
    (tmp_path / "d.txt").write_text("x", encoding="utf-8")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "skip.json").write_text("{\"x\":1}", encoding="utf-8")

    files = sorted(p.name for p in iter_supported_files(tmp_path))
    assert files == ["a.yaml", "b.json", "c.xml", "d.wsdl"]


def test_iter_supported_files_accepts_file_path(tmp_path: Path) -> None:
    p = tmp_path / "single.json"
    p.write_text("{\"a\":1}\n", encoding="utf-8")

    files = list(iter_supported_files(p))
    assert files == [p]


def test_normalize_yaml_file_autofixes(tmp_path: Path) -> None:
    p = tmp_path / "bad.yaml"
    p.write_text("name:   test\nitems:\n  - a\n  -  b", encoding="utf-8")

    result = normalize_yaml_file(p, check_only=False)
    assert result.error is None
    assert result.changed is True
    assert p.read_text(encoding="utf-8").endswith("\n")


def test_normalize_yaml_file_reports_parse_error(tmp_path: Path) -> None:
    p = tmp_path / "broken.yaml"
    p.write_text("key: [1, 2\n", encoding="utf-8")

    result = normalize_yaml_file(p)
    assert result.error is not None
    assert result.changed is False


def test_normalize_yaml_file_recovers_leading_tabs(tmp_path: Path) -> None:
    p = tmp_path / "tabbed.yaml"
    p.write_text("root:\n\tchild: 1\n", encoding="utf-8")

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True
    assert p.read_text(encoding="utf-8") == "root:\n  child: 1\n"


def test_normalize_yaml_file_recovers_common_top_level_indent_error(tmp_path: Path) -> None:
    p = tmp_path / "storageClass.yaml"
    p.write_text(
        (
            "apiVersion: storage.k8s.io/v1\n"
            "kind: StorageClass\n"
            "metadata:\n"
            "  name: ebs-sc\n"
            "provisioner: ebs.csi.aws.com\n"
            "volumeBindingMode: WaitForFirstConsumer\n"
            "allowVolumeExpansion: true\n"
            "     reclaimPolicy: Retain\n"
        ),
        encoding="utf-8",
    )

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True
    assert "reclaimPolicy: Retain\n" in p.read_text(encoding="utf-8")


def test_normalize_yaml_file_recovers_multi_line_weird_indents(tmp_path: Path) -> None:
    p = tmp_path / "storageClass.yaml"
    p.write_text(
        (
            "apiVersion: storage.k8s.io/v1\n"
            "kind: StorageClass\n"
            "metadata:\n"
            "  name: ebs-sc\n"
            "                    provisioner: ebs.csi.aws.com\n"
            "\n"
            "\n"
            "    volumeBindingMode: WaitForFirstConsumer\n"
            "allowVolumeExpansion: true\n"
            "                                                          reclaimPolicy: Retain\n"
        ),
        encoding="utf-8",
    )

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True

    fixed = p.read_text(encoding="utf-8")
    assert "provisioner: ebs.csi.aws.com\n" in fixed
    assert "volumeBindingMode: WaitForFirstConsumer\n" in fixed
    assert "reclaimPolicy: Retain\n" in fixed


def test_normalize_structured_file_formats_json(tmp_path: Path) -> None:
    p = tmp_path / "data.json"
    p.write_text("{\"name\":\"test\",\"items\":[1,2]}", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    assert result.file_type == "json"
    assert p.read_text(encoding="utf-8") == '{\n  "name": "test",\n  "items": [\n    1,\n    2\n  ]\n}\n'


def test_normalize_structured_file_reports_json_error(tmp_path: Path) -> None:
    p = tmp_path / "broken.json"
    p.write_text("{\"x\": 1,}", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is not None
    assert "JSON parse error:" in result.error
    assert result.changed is False


def test_normalize_structured_file_formats_xml(tmp_path: Path) -> None:
    p = tmp_path / "data.xml"
    p.write_text("<root><item>1</item><item>2</item></root>", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    assert result.file_type == "xml"
    assert p.read_text(encoding="utf-8") == "<root>\n  <item>1</item>\n  <item>2</item>\n</root>\n"


def test_normalize_structured_file_reports_xml_error(tmp_path: Path) -> None:
    p = tmp_path / "broken.xml"
    p.write_text("<root>\x00</root>", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is not None
    assert "XML parse error:" in result.error
    assert result.changed is False


def test_normalize_structured_file_repairs_simple_misnested_xml(tmp_path: Path) -> None:
    p = tmp_path / "misnested.xml"
    p.write_text("<root><a></root>", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    assert p.read_text(encoding="utf-8") == "<root>\n  <a />\n</root>\n"


def test_normalize_structured_file_xml_fixes_leading_whitespace_before_declaration(tmp_path: Path) -> None:
    p = tmp_path / "decl.xml"
    p.write_text("\n \t<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root><a>1</a></root>", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    fixed = p.read_text(encoding="utf-8")
    assert fixed.startswith("<?xml version='1.0' encoding='utf-8'?>\n")
    assert "<root>\n  <a>1</a>\n</root>\n" in fixed


def test_normalize_structured_file_xml_preserves_declaration_with_bom(tmp_path: Path) -> None:
    p = tmp_path / "bom.xml"
    p.write_text("\ufeff<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root><a>1</a></root>\n", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    fixed = p.read_text(encoding="utf-8")
    assert fixed.startswith("<?xml version='1.0' encoding='utf-8'?>\n")


def test_normalize_structured_file_xml_repairs_bad_public_doctype_and_unclosed_tags(tmp_path: Path) -> None:
    p = tmp_path / "test.xml"
    p.write_text(
        (
            "<!DOCTYPE glossary PUBLIC \"-//OASIS//DTD DocBook V3.1//EN\">\n"
            "<glossary><title>example glossary</title>\n"
            "<GlossDiv><title>S</title>\n"
            "<GlossList>\n"
            "<GlossEntry ID=\"SGML\" SortAs=\"SGML\">\n"
            "<GlossTerm>Standard Generalized Markup Language</GlossTerm>\n"
            "<Acronym>SGML</Acronym><Abbrev>ISO 8879:1986</Abbrev>\n"
            "<GlossDef><para>A meta-markup language</para>\n"
            "<GlossSeeAlso OtherTerm=\"GML\">\n"
            "<GlossSeeAlso OtherTerm=\"XML\">\n"
            "</GlossDef>\n"
            "<GlossSee OtherTerm=\"markup\">\n"
            "</GlossEntry>\n"
            "</GlossList>\n"
            "</GlossDiv>\n"
            "</glossary>\n"
        ),
        encoding="utf-8",
    )

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    fixed = p.read_text(encoding="utf-8")
    assert fixed.startswith("<!DOCTYPE glossary>\n")
    assert "</Glossary>" not in fixed
    assert "<GlossSeeAlso OtherTerm=\"XML\" />" in fixed
    assert "<GlossSee OtherTerm=\"markup\" />" in fixed


def test_normalize_yaml_file_repairs_pathological_indent_noise(tmp_path: Path) -> None:
    p = tmp_path / "postgres-deployment.yaml"
    p.write_text(
        (
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: postgres\n"
            "spec:\n"
            "  replicas: 1\n"
            "  selector:\n"
            "    matchLabels:\n"
            "      app: postgres\n"
            "                                                     template:\n"
            "    metadata:\n"
            "      labels:\n"
            "        app: postgres\n"
            "    spec:\n"
            "      containers:\n"
            "      - name: postgres\n"
            "        image: 'postgres:14'\n"
            "        imagePullPolicy: IfNotPresent\n"
            "                                                ports:\n"
            "        - containerPort: 5432\n"
            " envFrom:\n"
            "        - configMapRef:\n"
            "            name: postgres-secret\n"
            "        volumeMounts:\n"
            "        - mountPath: /var/lib/postgresql/data\n"
            "          name: postgresdata\n"
            "                                                   volumes:\n"
            "      - name: postgresdata\n"
            "        persistentVolumeClaim:\n"
            "          claimName: postgres-volume-claim\n"
        ),
        encoding="utf-8",
    )

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True

    fixed = p.read_text(encoding="utf-8")
    assert "template:\n" in fixed
    assert "ports:\n" in fixed
    assert "envFrom:\n" in fixed
    assert "volumes:\n" in fixed
